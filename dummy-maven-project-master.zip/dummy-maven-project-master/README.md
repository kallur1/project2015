# dummy-maven-project
A dummy maven project to experiment with CI/CD.
